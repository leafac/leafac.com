#lang racket
(require redex "terms.rkt" "languages.rkt")

(define
  ⇨
  (reduction-relation
   peg-solitaire
   #:domain board

   (--> (row_1
         ...
         [position_1 ... ● ● ○ position_2 ...]
         row_2
         ...)
        (row_1
         ...
         [position_1 ... ○ ○ ● position_2 ...]
         row_2
         ...)
        "→")

   (--> (row_1
         ...
         [position_1 ... ○ ● ● position_2 ...]
         row_2
         ...)
        (row_1
         ...
         [position_1 ... ● ○ ○ position_2 ...]
         row_2
         ...)
        "←")

   (--> (row_1
         ...
         [position_1 ..._n ● position_2 ...]
         [position_3 ..._n ● position_4 ...]
         [position_5 ..._n ○ position_6 ...]
         row_2
         ...)
        (row_1
         ...
         [position_1 ...   ○ position_2 ...]
         [position_3 ...   ○ position_4 ...]
         [position_5 ...   ● position_6 ...]
         row_2
         ...)
        "↓")

   (--> (row_1
         ...
         [position_1 ..._n ○ position_2 ...]
         [position_3 ..._n ● position_4 ...]
         [position_5 ..._n ● position_6 ...]
         row_2
         ...)
        (row_1
         ...
         [position_1 ...   ● position_2 ...]
         [position_3 ...   ○ position_4 ...]
         [position_5 ...   ○ position_6 ...]
         row_2
         ...)
        "↑")))

(test-equal (apply-reduction-relation ⇨ (term initial-board))
            '(((· · ● ● ● · ·)
               (· · ● ● ● · ·)
               (● ● ● ● ● ● ●)
               (● ● ● ● ● ● ●)
               (● ● ● ○ ● ● ●)
               (· · ● ○ ● · ·)
               (· · ● ● ● · ·))

              ((· · ● ● ● · ·)
               (· · ● ○ ● · ·)
               (● ● ● ○ ● ● ●)
               (● ● ● ● ● ● ●)
               (● ● ● ● ● ● ●)
               (· · ● ● ● · ·)
               (· · ● ● ● · ·))

              ((· · ● ● ● · ·)
               (· · ● ● ● · ·)
               (● ● ● ● ● ● ●)
               (● ● ● ● ○ ○ ●)
               (● ● ● ● ● ● ●)
               (· · ● ● ● · ·)
               (· · ● ● ● · ·))

              ((· · ● ● ● · ·)
               (· · ● ● ● · ·)
               (● ● ● ● ● ● ●)
               (● ○ ○ ● ● ● ●)
               (● ● ● ● ● ● ●)
               (· · ● ● ● · ·)
               (· · ● ● ● · ·))))

(test-equal (apply-reduction-relation* #:all? #t ⇨ (term ([● ● ● ○ ● ● ●])))
            '(((○ ○ ● ○ ● ○ ●))

              ((● ○ ○ ● ● ● ●))

              ((● ○ ● ○ ○ ● ●))

              ((● ○ ● ○ ● ○ ○))

              ((● ● ○ ○ ● ○ ●))

              ((● ● ● ● ○ ○ ●))))

(test-equal (apply-reduction-relation* ⇨ (term ([● ● ● ○ ● ● ●])))
            '(((○ ○ ● ○ ● ○ ●))

              ((● ○ ● ○ ● ○ ○))))

(provide ⇨)
